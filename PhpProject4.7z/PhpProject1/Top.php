<?php
//session_start();
//if((!isset($_SESSION['userid'])==true)and (!isset($_SESSION['passwordinput'])==true)){
//    unset($_SESSION['userid']);
//    unset($_SESSION['passwordinput']);
//    header('Location:index.php');
//}else{
//    $logado=$_SESSION['userid'];
//}


